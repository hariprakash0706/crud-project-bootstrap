import React from "react";

export default function UserTable({ users, onEditClick, onDelete }) {
  return (
    <div className="card mt-4">
      <div className="card-header">
        <h2 className="h5">Users</h2>
      </div>
      <div className="card-body p-0">
        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead className="table-light">
              <tr>
                <th style={{width: "10%"}}>#</th>
                <th style={{width: "35%"}}>Name</th>
                <th style={{width: "35%"}}>Email</th>
                <th style={{width: "20%"}}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.length === 0 ? (
                <tr>
                  <td colSpan="4" className="text-center py-4">No users found</td>
                </tr>
              ) : users.map((u, idx) => (
                <tr key={u.id}>
                  <td>{idx + 1}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>
                    <button className="btn btn-sm btn-primary me-2" onClick={() => onEditClick(u)}>
                      Edit
                    </button>
                    <button className="btn btn-sm btn-danger" onClick={() => onDelete(u.id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
