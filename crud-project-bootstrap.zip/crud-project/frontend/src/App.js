import React, { useEffect, useState } from "react";
import UserTable from "./components/UserTable";
import "./App.css";

const API = "http://localhost:5000";

function App() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: "", email: "" });
  const [editId, setEditId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function fetchUsers() {
    try {
      setLoading(true);
      const res = await fetch(`${API}/users`);
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error(err);
      setError("Failed to fetch users");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchUsers();
  }, []);

  function validate() {
    if (!form.name.trim() || !form.email.trim()) {
      setError("Name and email are required.");
      return false;
    }
    // simple email check
    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      setError("Please enter a valid email.");
      return false;
    }
    setError("");
    return true;
  }

  async function handleAddOrUpdate(e) {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (editId) {
        // update
        const res = await fetch(`${API}/users/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form)
        });
        if (!res.ok) throw new Error("Update failed");
        const updated = await res.json();
        setUsers(users.map(u => (u.id === updated.id ? updated : u)));
        setEditId(null);
      } else {
        // create
        const res = await fetch(`${API}/users`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form)
        });
        if (!res.ok) throw new Error("Create failed");
        const newUser = await res.json();
        setUsers([...users, newUser]);
      }

      setForm({ name: "", email: "" });
    } catch (err) {
      console.error(err);
      setError("Operation failed. Check backend console.");
    }
  }

  function onEditClick(user) {
    setEditId(user.id);
    setForm({ name: user.name, email: user.email });
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function onDelete(id) {
    if (!window.confirm("Delete this user?")) return;
    try {
      const res = await fetch(`${API}/users/${id}`, { method: "DELETE" });
      if (res.status !== 204) throw new Error("Delete failed");
      setUsers(users.filter(u => u.id !== id));
    } catch (err) {
      console.error(err);
      setError("Delete failed. Check backend.");
    }
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h2>CRUD OPERATIONS USING REACT</h2>
        </div>
        <div className="card-body">
          <form onSubmit={handleAddOrUpdate} className="row g-3 align-items-end">
            <div className="col-md-5">
              <label className="form-label">Name</label>
              <input
                className="form-control"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="Enter name"
              />
            </div>
            <div className="col-md-5">
              <label className="form-label">Email</label>
              <input
                className="form-control"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="Enter email"
              />
            </div>
            <div className="col-md-2">
              <button type="submit" className="btn btn-success w-100">
                {editId ? "Update" : "Add User"}
              </button>
            </div>
            {error && (
              <div className="col-12">
                <div className="alert alert-danger py-2 mb-0">{error}</div>
              </div>
            )}
          </form>
        </div>
      </div>

      {loading ? (
        <div className="text-center mt-4">Loading...</div>
      ) : (
        <UserTable users={users} onEditClick={onEditClick} onDelete={onDelete} />
      )}
    </div>
  );
}

export default App;
