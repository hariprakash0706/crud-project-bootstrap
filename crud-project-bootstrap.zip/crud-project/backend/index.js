const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(cors());
app.use(express.json());

const DB_PATH = path.join(__dirname, "db.json");

function readDB() {
  const data = fs.readFileSync(DB_PATH, "utf8");
  return JSON.parse(data);
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf8");
}

/**
 * GET /users
 * Return all users
 */
app.get("/users", (req, res) => {
  const db = readDB();
  res.json(db.users || []);
});

/**
 * POST /users
 * Create a new user
 */
app.post("/users", (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "Name and email are required" });
  }
  const db = readDB();
  const newUser = { id: uuidv4(), name, email };
  db.users = db.users || [];
  db.users.push(newUser);
  writeDB(db);
  res.status(201).json(newUser);
});

/**
 * PUT /users/:id
 * Update a user by id
 */
app.put("/users/:id", (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;
  const db = readDB();
  const idx = (db.users || []).findIndex(u => u.id === id);
  if (idx === -1) return res.status(404).json({ error: "User not found" });
  db.users[idx] = { ...db.users[idx], name, email };
  writeDB(db);
  res.json(db.users[idx]);
});

/**
 * DELETE /users/:id
 */
app.delete("/users/:id", (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const newUsers = (db.users || []).filter(u => u.id !== id);
  db.users = newUsers;
  writeDB(db);
  res.status(204).send();
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
